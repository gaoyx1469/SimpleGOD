delete from Person where id = ?

-- binding parameter [1] as [BIGINT] - [1]