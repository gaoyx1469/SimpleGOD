SELECT DISTINCT
    p.last_name as col_0_0_
FROM person p