INSERT INTO
    Event (location, name, id)
VALUES
    ('POINT (10 5)', 'Hibernate ORM presentation', 1)